p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
add = ''
if 'RECORD_AUDIO' not in s:
    add += '    <uses-permission android:name="android.permission.RECORD_AUDIO" />\n'
if '<queries>' not in s:
    add += ('    <queries>\n'
            '        <intent><action android:name="android.speech.RecognitionService" /></intent>\n'
            '        <intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>\n'
            '    </queries>\n')
s = s.replace('<application', add + '    <application', 1)
open(p, 'w', encoding='utf-8').write(s)
print('manifest ok')
